class List < ApplicationRecord
  # Active Storage を利用して画像アップロードを可能にするために以下の1行を追加
  has_one_attached :image
end
